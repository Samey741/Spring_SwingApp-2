rootProject.name = "cipherSpringAPP"
